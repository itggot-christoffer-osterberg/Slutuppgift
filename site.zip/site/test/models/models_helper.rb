# Configuration for model tests (rake test:models)

require_relative '../test_helper'

